
public interface SysParameter {
	
	public static final int BOOT_PORT = 2008;
	public static final String BOOT_IP = "glados.cs.rit.edu";

	public static final int CAN_PORT = 2014;
	
	public static final int TCP_PORT = 2015;
	
	public static final String FIND_SIGN = "find";
	public static final String FAIL_SIGN = "fail";
}
